<html>

<head>
    <title>LEMBAR DISPOSISI SURAT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 11pt;
        }

        footer {
            position: fixed;
            bottom: -40px;
            left: 0px;
            right: 0px;
            height: 50px;
            font-size: 9pt;

            /** Extra personal styles **/
            text-align: center;
            line-height: 35px;
        }

        .line {
            line-height: 50%;
        }
    </style>
    
    <table class="table table-bordered table-active" bgcolor="#FFFFFF">
        <tr>
            <td colspan="6" align="center">
                <h6>LEMBAR DISPOSISI</h6>
            </td>
        </tr>
        <tr>
            <td>
                Tanggal Surat
            </td>
            <td colspan="4"> <?php echo e($smasuk->tgl_surat); ?></td>
            <td rowspan="2">Kode : <br> <b><?php echo e($smasuk->kode); ?></b></td>
        </tr>
        <tr>
            <td>
                Nomor Surat
            </td>
            <td colspan="4"> <?php echo e($smasuk->no_surat); ?></td>
        </tr>
        <tr>
            <td>
                Asal Surat
            </td>
            <td colspan="5"> <?php echo e($smasuk->asal_surat); ?></td>
        </tr>
        <tr>
            <td>
                Isi Ringkas
            </td>
            <td colspan="5"> <?php echo e($smasuk->isi); ?></td>
        </tr>
        
        <tr>
            <td>
                No. Agenda
            </td>
            <td colspan="5">
                <?php echo e($smasuk->id); ?><br>
            </td>
        </tr>
        <tr>
            <td>
                Diteruskan Kepada
            </td>
            <td colspan="5">
                <?php echo e($disp->tujuan); ?><br>
            </td>
        </tr>
        <tr>
            <td>
                Isi Disposisi
            </td>
            <td colspan="5">
                <?php echo e($disp->isi); ?><br>
            </td>
        </tr>
        <tr>
            <td>
                Batas Waktu
            </td>
            <td colspan="5">
                <?php echo e($disp->tgl_disp); ?><br>
            </td>
        </tr>
        
        <tr>
            <td>
                Catatan
            </td>
            <td colspan="5">
                <?php echo e($disp->catatan); ?><br>
            </td>
        </tr>
    </table>
    <br>
    <p align="right" class="ml-4"> Kepala Dinas, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <br><br><br><b>........................</b> </p>
    </div>
    
</body>

<script type="text/javascript">
    window.print();
</script>

</html>
<?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/disposisi/cetak.blade.php ENDPATH**/ ?>