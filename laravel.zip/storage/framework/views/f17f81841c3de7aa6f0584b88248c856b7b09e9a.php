<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <h3><i class="nav-icon fas fa-user my-1 btn-sm-1"></i> Users</h3>
                <hr>
            </div>
        </div>
        <div>
            <div class="col">
                <a class="btn btn-primary btn-sm my-1 mr-sm-1" href="<?php echo e(route('user.create')); ?>" role="button"><i
                        class="fas fa-plus"></i> Tambah Data</a>
                <br><br>
            </div>
        </div>
        <div class="row table-responsive">
            <div class="col-12">
                <table class="table table-hover table-head-fixed" id='tabelSuratmasuk'>
                    <thead>
                        <tr class="bg-light">
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Unit Kerja</th>
                            <th>Email</th>
                            <th>Level</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($pengguna->name); ?></td>
                            <td><?php echo e($pengguna->unit_kerja); ?></td>
                            <td><?php echo e($pengguna->email); ?></td>
                            <td><?php echo e($pengguna->role); ?></td>
                            <td>
                                <form action="<?php echo e(route('user.destroy', $pengguna->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a href="<?php echo e(route('user.edit', $pengguna->id)); ?>"
                                        class="btn btn-primary btn-sm my-1 mr-sm-1"><i
                                            class="nav-icon fas fa-pencil-alt"></i> Edit</a>
                                    <button type="submit" class="btn btn-danger btn-sm my-1 mr-sm-1"
                                        onclick="return confirm('Hapus Data ?')"><i class="nav-icon fas fa-trash"></i>
                                        Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/users/user.blade.php ENDPATH**/ ?>