
<!DOCTYPE html>
<html>
<head>
	<title>CETAK SURAT</title>
	<style type="text/css">
		table {
			border-style: double;
			border-width: 3px;
			border-color: white;
		}
		table tr .text2 {
			text-align: right;
			font-size: 13px;
		}
		table tr .text {
			text-align: center;
			font-size: 13px;
		}
		table tr td {
			font-size: 13px;
		}

	</style>
</head>
<body>
    <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<center>
		<table>
			<tr>
				<td><img src="<?php echo e(asset('adminLTE/')); ?>/dist/img/logocapil.png" width="70" height="80"></td>
				<td>
				<center>
					<font size="4">PEMERINTAHAN KOTA TEGAL</font><br>
					<font size="5"><b>DINAS KEPENDUDUKAN KOTA TEGAL</b></font><br>
					
					<font size="2"><i>Jln Cut Nya'Dien No. 02 Kode Pos : 68173 Telp./Fax (0331)758005 Tempurejo Jember Jawa Timur</i></font>
				</center>
				</td>
			</tr>
			<tr>
				<td colspan="2"><hr></td>
			</tr>
		<table width="625">
			<tr>
				<td class="text2"><?php echo e($s->tempat_surat); ?>, <?php echo e(\Carbon\Carbon::parse($s->tgl_surat)->format('d-m-Y')); ?></td>
			</tr>
		</table>
		</table>
		<table>
			<tr class="text2">
				<td>Nomer</td>
				<td width="572"> : <?php echo e($s->no_surat); ?></td>
			</tr>
            <tr>
				<td>Lamp</td>
				<td width="564"> : <?php echo e($s->lampiran); ?></td>
			</tr>
			<tr>
				<td>Perihal</td>
				<td width="564"> : <?php echo e($s->perihal); ?></td>
			</tr>
		</table>
		<br>
		<table width="625">
			<tr>
		       <td>
			       <font size="2">Kpd yth.<br><?php echo e($s->tujuan_surat); ?><br>Di tempat</font>
		       </td>
		    </tr>
		</table>
		<br>
        
		<table width="625">
			<tr>
		       <td>
			       <font size="2"><?php echo e($s->salam_pembuka); ?></font>
		       </td>

		    </tr>
            <tr>
                <td style="text-indent: 30px;">
                <font size="2"><?php echo e($s->isi); ?></font>
                </td>
            </tr>
		</table>
		<br>
		</table>
		<table>
			<tr class="text2">
				<td></td>
				<td width="620"><?php echo e($s->isi1); ?></td>
			</tr>
			<tr>
				<td></td>
				<td width="620"><?php echo e($s->isi2); ?></td>
			</tr>
			<tr>
				<td></td>
				<td width="620" ><?php echo e($s->isi3); ?></td>
			</tr>
		</table>
		<br>
		<table width="625">
			<tr>
		       <td>
			       <font size="2"><?php echo e($s->salam_penutup); ?></font>
		       </td>
		    </tr>
		</table>
		<br>
		<table width="625">
			<tr>
				<td width="430"><br><br><br><br></td>
				<td class="text" align="center">Kepala Dinas<br><img src="<?php echo e(asset('adminLTE/')); ?>/dist/img/ttd.png" width="60" height="60"><br>Basuki, S.E.,M.M</td>
			</tr>
	     </table>
         <table>
			<tr class="625">
				<td>Tembusan :</td>
                <tr><td width="600"><?php echo e($s->tembusan1); ?></td></tr>
                <tr><td width="562"><?php echo e($s->tembusan2); ?></td></tr>
                <tr><td width="562"><?php echo e($s->tembusan3); ?></td></tr>
			</tr>

		</table>
	</center>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript">
        window.print();
    </script>
</body>
</html>

<?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/surats/edaran/cetaksurat.blade.php ENDPATH**/ ?>