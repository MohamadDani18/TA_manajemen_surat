<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-user-alt mr-1"></i>Surat Masuk
        <a href="<?php echo e(route('suratmasuk.create')); ?>" class="btn btn-primary btn-sm pull-right ml-2">Tambah Data</a>

    <div class="card-body">
        <div class="row table-responsive">
            <div class="col">
                <table class="table table-hover table-head-fixed" id='tabelSuratmasuk'>
                    <thead>
                        <tr class="bg-light">
                            <th>No.</th>
                            <th>Isi Ringkas</th>
                            <th>File</th>
                            <th>Asal Surat</th>
                            <th>Kode</th>
                            <th>No. Surat</th>
                            <th>Tgl. Surat</th>
                            <th>Tgl. Diterima</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $data_suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suratmasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($suratmasuk->isi); ?></td>
                            <td><a href="/suratmasuk/<?php echo e($suratmasuk->id); ?>/tampil"><?php echo e($suratmasuk->filemasuk); ?></a></td>
                            <td><?php echo e($suratmasuk->asal_surat); ?></td>
                            <td><?php echo e($suratmasuk->kode); ?></td>
                            <td><?php echo e($suratmasuk->no_surat); ?></td>
                            <td><?php echo e($suratmasuk->tgl_surat); ?></td>
                            <td><?php echo e($suratmasuk->tgl_terima); ?></td>
                            <td><?php echo e($suratmasuk->keterangan); ?></td>
                            <td>
                                <a href="/suratmasuk/<?php echo e($suratmasuk->id); ?>/edit"
                                    class="btn btn-primary btn-sm my-1 mr-sm-1 btn-block"><i
                                        class="nav-icon fas fa-pencil-alt"></i> Edit</a>
                                <a href="<?php echo e(route('disposisi.index', $suratmasuk->id)); ?>"
                                    class="btn btn-primary btn-sm my-1 mr-sm-1 btn-block"><i
                                        class="fas fa-file-alt"></i> Disposisi</a>
                                <?php if(auth()->user()->role == '1'): ?>
                                <a href="/suratmasuk/<?php echo e($suratmasuk->id); ?>/delete"
                                    class="btn btn-danger btn-sm my-1 mr-sm-1 btn-block"
                                    onclick="return confirm('Hapus Data ?')"><i class="nav-icon fas fa-trash"></i>
                                    Hapus</a>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>
  <!-- /.card -->


  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/suratmasuk/index.blade.php ENDPATH**/ ?>