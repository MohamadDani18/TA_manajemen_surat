
<!DOCTYPE html>
<html>
<head>
	<title>CETAK SURAT</title>
	<style type="text/css">
		table {
			border-style: double;
			border-width: 3px;
			border-color: white;
		}
		table tr .text2 {
			text-align: right;
			font-size: 13px;
		}
		table tr .text {
			text-align: center;
			font-size: 13px;
		}
		table tr td {
			font-size: 13px;
		}

	</style>
</head>
<body>
    <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<center>
		<table>
			<tr>
				<td><img src="<?php echo e(asset('adminLTE/')); ?>/dist/img/logocapil.png" width="70" height="80"></td>
				<td>
				<center>
					<font size="4">PEMERINTAHAN KOTA TEGAL</font><br>
					<font size="5"><b>DINAS KEPENDUDUKAN KOTA TEGAL</b></font><br>
					
					<font size="2"><i>Jln Cut Nya'Dien No. 02 Kode Pos : 68173 Telp./Fax (0331)758005 Tempurejo Jember Jawa Timur</i></font>
				</center>
				</td>
			</tr>
			<tr>
				<td colspan="2"><hr></td>
			</tr>
		<table width="625">
			<tr>
				<td class="text2"><?php echo e($s->tempat_surat); ?>, <?php echo e(\Carbon\Carbon::parse($s->tgl_surat)->format('d-m-Y')); ?></td>
			</tr>
		</table>
		</table>
        <table width="625">
			<tr>
		       <td>
			       <center><font size="3"> SURAT PERINTAH <br>Nomor: <?php echo e($s->no_surat); ?></font></center>
		       </td>
		    </tr>
		</table>
		<br>

		<table width="625">
			<tr>
		       <td>
			       <font size="2"><?php echo e($s->salam_pembuka); ?><br><?php echo e($s->isi); ?></font>
		       </td>
		    </tr>
		</table>
		<br>
		</table>
		<table>
            <tr>
				<td>Nama</td>
				<td width="525">: <?php echo e($s->nama); ?></td>
			</tr>
			<tr>
				<td>Nip</td>
				<td width="525">: <?php echo e($s->nip); ?></td>
			</tr>
            <tr>
				<td>Unit Kerja</td>
				<td width="525">: <?php echo e($s->unitkerja); ?></td>
			</tr>
			<tr>
				<td>Tugas</td>
				<td width="525">: <?php echo e($s->tugas); ?></td>
			</tr>
			<tr class="text2">
				<td>Hari Tanggal</td>
				<td width="525">: <?php echo e($s->hari_tgl); ?></td>
			</tr>
			<tr>
				<td>Jam</td>
				<td width="525">: <?php echo e($s->waktu); ?></td>
			</tr>
			<tr>
				<td>Tempat</td>
				<td width="525">: <?php echo e($s->tempat); ?></td>
			</tr>
		</table>
		<br>
		<table width="625">
			<tr>
		       <td>
			       <font size="2"><?php echo e($s->salam_penutup); ?></font>
		       </td>
		    </tr>
		</table>
		<br>
		<table width="625">
			<tr>
				<td width="430"><br><br><br><br></td>
				<td class="text" align="center">Kepala Dinas<br><img src="<?php echo e(asset('adminLTE/')); ?>/dist/img/ttd.png" width="60" height="60"><br>Basuki, S.E.,M.M</td>
			</tr>
	     </table>
	</center>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script type="text/javascript">
        window.print();
    </script>
</body>
</html>

<?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/surats/perintah/cetaksurat.blade.php ENDPATH**/ ?>