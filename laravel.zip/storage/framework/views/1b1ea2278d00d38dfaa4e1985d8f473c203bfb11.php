<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    

    <link rel="stylesheet" href="<?php echo e(asset('adminLTE/')); ?>/login/fonts/icomoon/style.css">

    <link rel="stylesheet" href="<?php echo e(asset('adminLTE/')); ?>/login/css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('adminLTE/')); ?>/login/css/bootstrap.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('adminLTE/')); ?>/login/css/style.css">

    <title>Login</title>
  </head>

  <?php echo $__env->yieldContent('content'); ?>

  <script src="<?php echo e(asset('adminLTE/')); ?>/login/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo e(asset('adminLTE/')); ?>/login/js/popper.min.js"></script>
  <script src="<?php echo e(asset('adminLTE/')); ?>/login/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('adminLTE/')); ?>/login/js/main.js"></script>
</html>
<?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/layouts/applogin.blade.php ENDPATH**/ ?>