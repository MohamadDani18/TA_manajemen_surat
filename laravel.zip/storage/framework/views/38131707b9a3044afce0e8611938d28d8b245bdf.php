<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('suratmasuk.store')); ?>" method="POST" enctype="multipart/form-data">
            <h4><div class="card-header"><i class="far fa-list-alt mr-1"></i></i>Tambah Surat Keluar</div></h4>
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-6">
                    <label for="nomorsurat">Nomor Surat</label>
                    <input value="<?php echo e(old('no_surat')); ?>" name="no_surat" type="text" class="form-control bg-light"
                        id="nomorsurat" placeholder="Nomor Surat" required>
                    <label for="asalsurat">Asal Surat</label>
                    <input value="<?php echo e(old('asal_surat')); ?>" name="asal_surat" type="text" class="form-control bg-light"
                        id="asalsurat" placeholder="Asal Surat" required>
                    <label for="isisurat">Isi Ringkas</label>
                    <textarea name="isi" class="form-control bg-light" id="isisurat" rows="3"
                        placeholder="Isi Ringkas Surat Masuk" required><?php echo e(old('isi')); ?></textarea>
                    <label for="kode">Kode Klasifikasi</label>
                    <select name="kode" class="custom-select my-1 mr-sm-2 bg-light" id="inlineFormCustomSelectPref"
                        required>
                        <option value="">-- Pilih Klasifikasi Surat --</option>
                        <?php $__currentLoopData = $data_klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klasifikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($klasifikasi->kode); ?>"><?php echo e($klasifikasi->nama); ?> ( <?php echo e($klasifikasi->kode); ?> )
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-6">
                    <label for="tglsurat">Tanggal Surat</label>
                    <input value="<?php echo e(old('tgl_surat')); ?>" name="tgl_surat" type="date" class="form-control bg-light"
                        id="tglsurat" required>
                    <label for="tglditerima">Tanggal Diterima</label>
                    <input value="<?php echo e(old('tgl_terima')); ?>" name="tgl_terima" type="date" class="form-control bg-light"
                        id="tglditerima" required>
                    <label for="keterangan">Keterangan</label>
                    <input value="<?php echo e(old('keterangan')); ?>" name="keterangan" type="text" class="form-control bg-light"
                        id="keterangan" placeholder="Keterangan" required>
                    <div class="form-group">
                        <label for="exampleFormControlFile1">File</label>
                        <input name="filemasuk" type="file" class="form-control-file" id="exampleFormControlFile1"
                            required>
                        <small id="exampleFormControlFile1" class="text-danger">
                            Pastikan file anda ( jpg,jpeg,png,doc,docx,pdf ) !!!
                        </small>
                    </div>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-success btn-sm "><i class="fas fa-save"></i> SIMPAN</button>
            <a class="btn btn-danger btn-sm" href="<?php echo e(route('suratmasuk.index')); ?>" role="button"><i class="fas fa-undo"></i> BATAL</a>
        </form>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/suratmasuk/create.blade.php ENDPATH**/ ?>