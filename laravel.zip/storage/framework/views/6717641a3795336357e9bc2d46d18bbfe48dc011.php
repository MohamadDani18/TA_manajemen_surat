<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('unitkerja.update',$unit_kerja->id)); ?>" method="POST" enctype="multipart/form-data">
            <h3><i class="nav-icon fas fa-layer-group my-1 btn-sm-1"></i> Edit Unit Kerja</h3>
            <hr>
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <?php echo method_field('PUT'); ?>
                <div class="col-6">
                    <label for="unit_kerja">Nama</label>
                    <input name="unit_kerja" type="text" class="form-control bg-light" id="unit_kerja"
                        placeholder="Unit Kerja" value="<?php echo e($unit_kerja->unit_kerja); ?>" required>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-success btn-sm "><i class="fas fa-save"></i> SIMPAN</button>
            <a class="btn btn-danger btn-sm" href="<?php echo e(route('unitkerja.index')); ?>" role="button"><i class="fas fa-undo"></i>
                BATAL</a>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/unitkerja/edit.blade.php ENDPATH**/ ?>