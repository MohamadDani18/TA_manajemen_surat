<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>


<div class="card mb-4">
    <div class="card-header"><i class="far fa-list-alt mr-1"></i></i>Detail Surat Masuk</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suratmasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th width="25%">Asal Surat</th>
                        <td><?php echo e($suratmasuk->asal_surat); ?></td>
                    </tr>
                    <tr>
                        <th>Nomer Surat</th>
                        <td><?php echo e($suratmasuk->no_surat); ?></td>
                    </tr>
                    
                    <tr>
                        <th>Kode Klasifikasi</th>
                        <td><?php echo e($suratmasuk->kode); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Surat</th>
                        <td><?php echo e($suratmasuk->tgl_surat); ?></td>
                    </tr>
                    <tr>
                        <th>Isi Ringkas</th>
                        <td><?php echo e($suratmasuk->isi); ?></td>
                    </tr>
                    <tr>
                        <th>File</th>
                        <td>
                            <div class="row">
                                <div class="col-8">
                                    <h5><?php echo e($suratmasuk->filemasuk); ?></h5>
                                </div>
                                <div class=col-4>
                                    <a style="float: right" class="btn btn-primary btn-sm my-4 mr-sm-2"
                                        href="/datasuratmasuk/<?php echo e($suratmasuk->filemasuk); ?>" download="<?php echo e($suratmasuk->filemasuk); ?>"
                                        role="button"><i class="fas fa-file-download"></i> Download</a>
                                    
                                </div>
                            </div>
                            
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/SuratMasuk/detail.blade.php ENDPATH**/ ?>