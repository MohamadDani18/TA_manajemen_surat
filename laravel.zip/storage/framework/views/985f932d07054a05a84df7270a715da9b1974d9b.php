<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 20px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <h5><i class="nav-icon fas fa-envelope my-1 btn-sm-1"></i> Verifikasi Surat</h5>
                <hr />
            </div>
        </div>
        <div class="row table-responsive">
            <div class="col">
                <table class="table table-bordered table-hover table-head-fixed" id='tabelSuratmasuk'>
                    <thead>
                        <tr class="bg-light">
                            <th>No.</th>
                            <th>No. Surat</th>
                            <th>Perihal</th>
                            <th>Tujuan Surat</th>
                            <th>Tempat Surat</th>
                            <th>Tgl. Surat</th>
                             <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($surat->no_surat); ?></td>
                            <td><?php echo e($surat->perihal); ?></td>
                            <td><?php echo e($surat->tujuan_surat); ?></td>
                            <td><?php echo e($surat->tempat_surat); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($surat->tgl_surat)->format('d-m-Y')); ?></td>
                            <td><?php echo e($surat->keterangan); ?></td>
                            <td>

                                    
                                        <?php if($surat->jenis_surat == 'surat edaran'): ?>
                                        <a class="btn btn-primary btn-sm my-1 mr-sm-1" target="_blank" href="<?php echo e(route('surat.tampiledaran', $surat->id)); ?>">
                                            <i class="fas fa-file-archive"></i> Show</a>
                                        <?php elseif($surat->jenis_surat == 'surat undangan'): ?>
                                        <a class="btn btn-primary btn-sm my-1 mr-sm-1" target="_blank" href="<?php echo e(route('surat.show', $surat->id)); ?>">
                                            <i class="fas fa-file-archive"></i> Show</a>
                                        <?php elseif($surat->jenis_surat == 'surat permohonan'): ?>
                                        <a class="btn btn-primary btn-sm my-1 mr-sm-1" target="_blank" href="<?php echo e(route('surat.tampilpermohonan', $surat->id)); ?>">
                                            <i class="fas fa-file-archive"></i> Show</a>
                                        <?php elseif($surat->jenis_surat == 'surat perintah'): ?>
                                        <a class="btn btn-primary btn-sm my-1 mr-sm-1" target="_blank" href="<?php echo e(route('surat.tampilperintah', $surat->id)); ?>">
                                            <i class="fas fa-file-archive"></i> Show</a>
                                        <?php else: ?>

                                        <?php endif; ?>

                                    <a class="btn btn-success btn-sm my-1 mr-sm-1 " data-toggle="modal"
                                    data-target="#tambahklasifikasi"><i class="nav-icon fas fa-edit"></i>Confirm</a>

                            </td>
                            <!--modal konfirmasi-->
        <div class="modal fade" id="tambahklasifikasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i
                            class="nav-icon fas fa-layer-group my-1 btn-sm-1"></i> Konfirmasi Surat</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('surat.update', $surat->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col">
                                <select name="keterangan" class="custom-select my-1 mr-sm-2 bg-light" id="keterangan" required>
                                    <option>Terverifikasi</option>
                                    <option>ditolak</option>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i>
                            SUBMIT</button>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/surats/index.blade.php ENDPATH**/ ?>