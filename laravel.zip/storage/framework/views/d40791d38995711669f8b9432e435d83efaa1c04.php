<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col">
                <h3><i class="nav-icon fas fa-envelope my-1 btn-sm-1"></i> Disposisi</h3>
                <hr />
            </div>
        </div>
        <div>
            <div class="col">
                <a class="btn btn-danger btn-sm my-1 mr-sm-1" href="<?php echo e(route('suratmasuk.index')); ?>" role="button"><i
                        class="fas fa-undo"></i> Kembali</a>
                        <?php if(auth()->user()->role == 'kepala'): ?>
                <a class="btn btn-primary btn-sm my-1 mr-sm-1" href="<?php echo e(route('disposisi.create', $smasuk)); ?>"
                    role="button"><i class="fas fa-plus"></i> Tambah Data</a>
                    <?php endif; ?>
                <br><br>
            </div>
        </div>
        <div class="row table-responsive">
            <div class="col">
                <table class="table table-hover table-head-fixed" id='tabelKlasifikasi'>
                    <thead>
                        <tr class="bg-light">
                            <th>No.</th>
                            <th>Tujuan</th>
                            <th>Isi Disposisi</th>
                            
                            <th>Tanggal</th>
                            <th>Catatan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disposisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($disposisi->tujuan); ?></td>
                            <td><?php echo e($disposisi->isi); ?></td>
                            
                            <td><?php echo e(\Carbon\Carbon::parse($disposisi->tgl_disp)->format('d-m-Y')); ?></td>
                            <td><?php echo e($disposisi->catatan); ?></td>
                            <td>
                                <form action="<?php echo e(route('disposisi.destroy', [$smasuk, $disposisi->id])); ?>"
                                    method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <?php if(auth()->user()->role == 'kepala'): ?>
                                    <a href="<?php echo e(route('disposisi.edit', [$smasuk, $disposisi->id])); ?>"
                                        class="btn btn-primary btn-sm my-1 mr-sm-1" role="button"><i
                                            class="nav-icon fas fa-pencil-alt"></i> Edit</a>
                                        <?php endif; ?>
                                    <a class="btn btn-primary btn-sm my-1 mr-sm-1"
                                         href="<?php echo e(route('disposisi.cetak', [$smasuk, $disposisi->id])); ?>"
                                        target="_blank" role="button"><i class="fas fa-print"></i> Cetak</a>
                                    <?php if(auth()->user()->role == 'kepala'): ?>
                                    
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/disposisi/index.blade.php ENDPATH**/ ?>