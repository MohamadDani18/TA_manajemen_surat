<?php $__env->startSection('content'); ?>
<section class="content card" style="padding: 10px 10px 10px 10px ">
    <div class="box">
        <?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('disposisi.store', $smasuk)); ?>" method="POST">
            <h3><i class="nav-icon fas fa-envelope-open-text my-1 btn-sm-1"></i> Tambah Disposisi</h3>
            <hr />
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-6">
                    <label for="tujuan">Tujuan</label>
                    <select name="tujuan" class="custom-select my-1 mr-sm-2 bg-light" id="inlineFormCustomSelectPref"
                        required>
                        
                        <?php $__currentLoopData = $unit_kerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_kerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unit_kerja->unit_kerja); ?>"><?php echo e($unit_kerja->unit_kerja); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="isi">Isi</label>
                    <input name="isi" type="text" class="form-control bg-light" placeholder="Isi" required>
                    <label for="batas_waktu">Tanggal</label>
                    <input name="tgl_disp" type="date" class="form-control bg-light" required>
                    <label for="catatan">Catatan</label>
                    <input name="catatan" type="text" class="form-control bg-light" placeholder="Catatan" required>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-success btn-sm "><i class="fas fa-save"></i> SIMPAN</button>
            <a class="btn btn-danger btn-sm" href="<?php echo e(route('disposisi.index', $smasuk)); ?>" role="button"><i
                    class="fas fa-undo"></i> BATAL</a>
        </form>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/disposisi/create.blade.php ENDPATH**/ ?>