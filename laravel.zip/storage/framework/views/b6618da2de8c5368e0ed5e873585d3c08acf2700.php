<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>

<?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

<div class="card mb-4">
    <div class="card-header"><i class="far fa-list-alt mr-1"></i></i>Cetak data Surat</div>
    <div class="card-body">
        <div class="table-responsive">
            <div class="form-group col-md-6">
                <label for="label">Tanggal Awal :</label>
                <input type="date" name="tglawal" id="tglawal" class="form-control bg-light " required>
            </div>
            <div class="form-group col-md-6">
                <label for="label">Tanggal Akhir :</label>
                <input type="date" name="tglakhir" id="tglakhir" class="form-control bg-light" required>
            </div>
            <div class="form-group col-md-6">
                <a href="" onclick="this.href='/cetak-laporan-filter/'+ document.getElementById('tglawal').value
                + '/' + document.getElementById('tglakhir').value" target="blank" class="btn btn-primary"><i class="fas fa-print"></i> Cetak Laporan </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/SuratMasuk/cetak-laporan-form.blade.php ENDPATH**/ ?>