<?php $__env->startSection('title', 'Jenis Surat'); ?>

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('jenissurat.create')); ?>" class="btn btn-primary mb-2">Tambah Data</a>

<div class="card mb-4">
    <div class="card-header"><i class="fas fa-user-alt mr-1"></i>Data Jenis Surat</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Jenis Surat</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(function() {
        var table = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e(route("jenissurat.index")); ?>'
            },
            columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'jenis_surat', name: 'jenis_surat'},
            {data: 'action', name: 'action',orderable : false, searchable: false}
            ]
          });
        });
    function deleteData(id) {
        swal({
            title: "Anda Yakin ?",
            text: "Data terhapus!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            $.ajaxSetup({
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        });
            if (willDelete) {
                $('#data' + id).submit();
            }
        })
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/jenissurat/jenis.blade.php ENDPATH**/ ?>