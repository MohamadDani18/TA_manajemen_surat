<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-user-alt mr-1"></i>Surat Keluar</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered data-table">
                <thead>
                    <tr>
                        <th>No.</th>
                            <th>No. Surat</th>
                            <th>Perihal</th>
                            <th>Tujuan Surat</th>
                            <th>Tempat Surat</th>
                            <th>Tgl. Surat</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
  <!-- /.card -->


  <script>
    $(document).ready(function(){
        var table = $('.data-table').DataTable({
            processing: true,
            serverSide: true,
            autoWidth: false,
            ajax: {url:"<?php echo e(route('surat.index')); ?>"},
            columns: [
                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                {data: 'no_surat', name: 'no_surat'},
                {data: 'perihal', name: 'perihal'},
                {data: 'tujuan_surat', name: 'tujuan_surat'},
                {data: 'tempat_surat', name: 'tempat surat'},
                {data: 'tgl_surat', name: 'tgl_surat'},
                {data: 'keterangan', name: 'keterangan'},
                // { data: 'filekeluar', name: 'filekeluar',
                //     render: function( data, type, full, meta ) {
                //         return "<img src=\"" + data + "\" height=\"50\"/>";
                //     }
                // },
                {data: 'action', name: 'action',orderable : false, searchable: false}
            ]
          });
        });
    function deleteData(id) {
        swal({
            title: "Anda Yakin ?",
            text: "Data terhapus!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            $.ajaxSetup({
            headers: {
                'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
            }
        });
            if (willDelete) {
                $('#data' + id).submit();
            }
        })
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/surats/verifikasi.blade.php ENDPATH**/ ?>