<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>

        table.static{
            position: relative;
            border: 1px solid #543535;
        }

    </style>
    <title>CETAK DATA SURAT</title>
</head>

<body>
    <div class="form-group">
        <p align="center"><b>Laporan Data Surat</b></p>
        <table class="table table-bordered">
            <tr>
                <th>No.</th>
                <th>Tujuan Surat</th>
                <th>No Surat</th>
                <th>Perihal</th>
                <th>Klasifikasi Surat</th>
                <th>tanggal Surat</th>
                <th>Status</th>
            </tr>

            <?php $__currentLoopData = $suratkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($s->tujuan_surat); ?></td>
                    <td><?php echo e($s->no_surat); ?></td>
                    <td><?php echo e($s->perihal); ?></td>
                    <td><?php echo e($s->jenis_surat); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($s->tgl_surat)->format('d-m-Y')); ?></td>
                    <td><?php echo e($s->keterangan); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>

    <script type="text/javascript">
        window.print();
    </script>

</body>
</html>
<?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/SuratKeluar/cetak-laporan.blade.php ENDPATH**/ ?>