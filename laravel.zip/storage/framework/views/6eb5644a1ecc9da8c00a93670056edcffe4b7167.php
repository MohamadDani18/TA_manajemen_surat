<?php $__env->startSection('title', 'Tambah'); ?>


<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="card mb-4">
    <div class="card-header"><i class="far fa-list-alt mr-1"></i></i>Edit Jenis Surat</div>
    <div class="card-body">
      <!-- form start -->
      <?php $__currentLoopData = $jenis_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <form action="<?php echo e(route('jenissurat.update', [$j->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="box-body">
            <div class="form-row">
            <?php echo e(method_field('PUT')); ?>

          <div class="form-group col-md-12">
            <label for="">Jenis Surat</label>
            <input type="text" name="jenis_surat" value="<?php echo e($j->jenis_surat); ?>" autocomplete="off" class="form-control form-control-border border-width-2" id="" placeholder="Masukan Jenis Surat">
          </div>

        <!-- /.box-body -->
      </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- /.card-body -->
    <div class="card-footer">
        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </div>
    <!-- /.card-footer-->
  </div>
  <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/JenisSurat/edit.blade.php ENDPATH**/ ?>