<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>
<?php if(session('sukses')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
<!-- Default box -->
<div class="card mb-4">
    <div class="card-header"><i class="far fa-list-alt mr-1"></i></i>Tambah User</div>
    <div class="card-body">
      <!-- form start -->
      <form action="<?php echo e(route('user.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="box-body">
            <div class="form-row">
          <div class="form-group col-md-12">
            <label for="">Nama</label>
            <input type="text" name="name" class="form-control form-control-border border-width-2" id="" placeholder="Masukan Nama">
          </div>
          <div class="form-group col-md-12">
            <label for="unit_kerja">Unit Kerja</label>
                    <select name="unit_kerja" class="form-control form-control-border border-width-2" id="inlineFormCustomSelectPref"
                        required>
                        
                        <?php $__currentLoopData = $unit_kerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_kerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($unit_kerja->unit_kerja); ?>"><?php echo e($unit_kerja->unit_kerja); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
          </div>
          <div class="form-group col-md-12">
            <label for="">Email</label>
            <input type="email" name="email" class="form-control form-control-border border-width-2" id="" placeholder="Masukan Email">
          </div>
          <div class="form-group col-md-12">
            <label for="role">Level</label>
                    <select name="role" id="role" class="form-control form-control-border border-width-2" required>
                        <option value="admin">Administrator</option>
                        <option value="pegawai">Pegawai</option>
                        
                    </select>
          </div>
          <div class="form-group col-md-12">
            <label for="">Password</label>
            <input type="password" name="password" class="form-control form-control-border border-width-2" id="" placeholder="Masukan Password">
          </div>

        <!-- /.box-body -->
      </form>
    </div>
    <!-- /.card-body -->
    <div class="card-footer">
        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
    <!-- /.card-footer-->
  </div>
  <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/users/create.blade.php ENDPATH**/ ?>