<?php $__env->startSection('title'); ?>


<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="card">

    <div class="card-header">
      <h3 class="card-title">STATISTIK APLIKASI MANAJEMEN SURAT</h3>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
          <i class="fas fa-minus"></i>
        </button>
        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
          <i class="fas fa-times"></i>
        </button>
      </div>
    </div>
    <div class="card-body">

        <div class="row">
            <div class="card-body">
                <!-- Small boxes (Stat box) -->
                <div class="filter-container p-0 row">
                    <?php if(auth()->user()->role == 'kepala'): ?>
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-teal">
                            <div class="inner">
                                <h3><?php echo e(DB::table('buatsurat')->where('keterangan','belum terverifikasi')->count()); ?></h3>
                                <p>Data Belum terverifikasi</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-paper-plane"></i>
                            </div>
                            <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->role == 'pegawai'): ?>
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-teal">
                            <div class="inner">
                                <h3><?php echo e(DB::table('buatsurat')->where('keterangan','belum terverifikasi')->count()); ?></h3>
                                <p>Permintaan Surat</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-paper-plane"></i>
                            </div>
                            <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-cyan">
                            <div class="inner">
                                <h3><?php echo e(DB::table('suratmasuk')->count()); ?></h3>
                                <p>Surat Masuk</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-envelope-open-text"></i>
                            </div>
                            <a href="<?php echo e(route('suratmasuk.index')); ?>" class="small-box-footer ">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-maroon">
                            <div class="inner">
                                <h3><?php echo e(DB::table('buatsurat')->where('keterangan','terverifikasi')->count()); ?></h3>
                                <p>Surat Keluar</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-envelope"></i>
                            </div>
                            <a href="<?php echo e(route('suratkeluar.index')); ?>" class="small-box-footer ">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <?php if(auth()->user()->role == 'admin'): ?>
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-blue">
                            <div class="inner">
                                <h3><?php echo e(DB::table('klasifikasi')->count()); ?></h3>
                                <p>Klasifikasi</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-layer-group"></i>
                            </div>
                            <a href="<?php echo e(route('klasifikasi.index')); ?>" class="small-box-footer">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- ./col -->
                    <?php if(auth()->user()->role == 'admin'): ?>
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-teal">
                            <div class="inner">
                                <h3><?php echo e(DB::table('users')->count()); ?></h3>
                                <p>Pengguna</p>
                            </div>
                            <div class="icon">
                                <i class="nav-icon fas fa-users"></i>
                            </div>
                            <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">Lihat Detail <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- ./col -->
                </div>
            </div>
        </div>
    </div>


    <!-- /.card-footer-->
  </div>
  <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Manajemen_surat\resources\views/layouts/beranda.blade.php ENDPATH**/ ?>