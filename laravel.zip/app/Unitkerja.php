<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unitkerja extends Model
{
    protected $table = 'unitkerja';
    protected $fillable = ['unit_kerja'];
}
